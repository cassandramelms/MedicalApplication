//Cassandra Melms
//9.21.20
//Course ID : CS 320-H1152
//Description: This will test the patient history functionality to ensure that it works. 
import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import medical.com.medicalApplication.model.Allergey;
import medical.com.medicalApplication.model.Medication;
import medical.com.medicalApplication.model.Treatment;


public class TestPatientHistory {
	private Treatment treatments;
	private Medication medications;
	private Allergy allergy;
	
	@Before
	public void before() {
		this.treatments = newTreatment("Chemo");
		this.medications = newMedication("Sprycel");
		this.allergy = newAllergy("Gleevec");
	}
	
	@Test
	public void test() {
		assertTrue(treatments.getTreatment().equals("Chemo"));
	}

	@Test
	public void test() {
		assertTrue(medications.getMedication().equals("Sprycel"));
	}
	public void test() {
		assertTrue(allergy.getAllergy().equals("Gleevec"));
	}

}
