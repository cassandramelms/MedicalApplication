//Cassandra Melms
//9.21.20
//Course ID : CS 320-H1152
//Description: This will test the treatment functionality to ensure that it works. 
import static org.junit.Assert.*;

import org.junit.Test;


public class TestTreatment {
	private Date treatmentDate;
	private Diagnose diagnose;
	private Description description;

	@Before 
	public void before() {
		this.treatmentDate = newDate("12.13.20")
		this.diagnose = newDiagnose("CML");
		this.description = newDescription("Test description");
	}
	@Test
	public void test() {
		assertTrue(treatmentDate.getDate().equals("12.13.20"));
	}
	
	@Test 
	public void test() {
		assertTrue(diagnose.getDiagnose().equals("CML"));
	}
	
	@Test 
	public void test() {
		assertTrue(description.getDiscription.equals("Test description"));
	}

}
