//Cassandra Melms
//9.21.20
//Course ID : CS 320-H1152
//Description: This will test the employee functionality to ensure that it works. 
package medical;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergey;

public class TestEmployee {
	private Employee employee;

	@Before
	public void before(){
		this.employee = newEmployee("John Smith", "12345");
		
	}

	@Test
	public void test SetName() {
		assertTrue(employee.getName().equals("John Smith"));
	}
	
	@Test 
	public void test SetId() {
		assertTrue(employee.getId().equals("12345"));
	}

}

