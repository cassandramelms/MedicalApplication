//Cassandra Melms
//9.21.20
//Course ID : CS 320-H1152
//Description: This will test the doctor functionality to ensure that it works. 
package medical;

import static org.junit.Assert.*;
import medical.com.medicalApplication.model.Doctor;

import org.junit.Before;
import org.junit.Test;


public class TestDoctor {
	private Doctor doctor; 
	
	@Before
	public void before(){
		this.doctor = new Doctor ("Smith", "123");
	}

	@Test
	public void testSetName(){
		assertTrue(doctor.getName().equals("Smith"));
	}
	
	@Test 
	public void testSetId(){
		assertTrue(doctor.getId().equals("123"));
		boolean doctor = !doctors.stream().anyMatch(doctor -> doctor.getId() != doctor.getId());
		
	}
}
