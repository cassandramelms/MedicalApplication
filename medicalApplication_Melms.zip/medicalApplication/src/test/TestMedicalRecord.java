//Cassandra Melms
//9.21.20
//Course ID : CS 320-H1152
//Description: This will test the medical record functionality to ensure that it works. 
package medical.com.medicalApplication.util;

import static org.junit.Assert.*;

import org.junit.Test;

import medical.com.medicalApplication.model.Patient;
import medical.com.medicalApplication.model.PatientHistory;

public class TestMedicalRecord {
	private Patient patient;
	private PatientHistory history;
	
	@Before 
	public void before() {
		this.patient = newPatient("John Doe");
		this.history = newPatientHistory("Test Information");
	}

	@Test
	public void test getPatient() {
		assertTrue(patient.getName().equals("John Doe"));
	}

	@Test 
	public void test getPatientHistory() {
		assertTrue(history.getHistory().equals("Test Information"));
	}
}
