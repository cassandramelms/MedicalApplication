//Cassandra Melms
//9.21.20
//Course ID : CS 320-H1152
//Description: This will test the medications functionality to ensure that it works. 
import static org.junit.Assert.*;

import org.junit.Test;


public class TestMedication {
	private Name name;
	private Start startDate;
	private End endDate;
	private Dose dose;

	@Before 
	public void before() {
		this.name = newName("Gleevec");
		this.startDate = newStart("12.12.19");
		this.endDate = newEnd("00.00.00");
		this.dose = newDose("400 mg");
	}
	@Test
	public void test getName() {
		assertTrue(name.getName().equals("Gleevec"));
	}
	
	@Test
	public void test getStart() {
		assertTrue(startDate.getStart().equals("12.12.19"));
	}
	
	@Test 
	public void test getEnd() {
		assertTrue(endDate.getEnd().equals.("00.00.00"));
		
	}
	
	@Test
	pulic void test getDose() {
		assertTrue(dose.getDose().equals.("400 mg"));
	}
}
