//Cassandra Melms
//9.21.20
//Course ID : CS 320-H1152
//Description: This will test the allergey functionality to ensure that it works. 

package medical.com.medicalApplication.model;
import static org.junit.Assert.*;
import medical.com.medicalApplication.model.Allergey;
import org.junit.Before;
import org.junit.Test;



public class testAllergy {
	private Allergey allergey;

	@Before
	public void before(){
		this.allergey = newAllergey("Peanuts");
		
	}

	@Test
	public void test SetName() {
		assertTrue(allergey.getName().equals("Peanuts"));
	}

}
