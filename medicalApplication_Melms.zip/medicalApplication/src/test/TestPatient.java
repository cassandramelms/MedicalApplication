//Cassandra Melms
//9.21.20
//Course ID : CS 320-H1152
//Description: This will test the patient functionality to ensure that it works. 
import static org.junit.Assert.*;

import org.junit.Test;


public class TestPatient {
	private Name name;
	private Id id;

	@Before
	public void before() {
		this.name = newName("John Doe");
		this.id = newId("12345");
	}
	@Test
	public void test() {
		assertTrue.getName().equals("John Doe");
	}
	
	@Test
	public void test() {
		assertTrue.getId().equals("12345");
	}

}
