package medical.com.medicalApplication.services;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestService {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
